package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.dao.EmployeeDAO;
import com.mindgate.pojo.Employee;

public class CrudCollection {
  public static void main(String[] args) {
	  EmployeeDAO employdao = new EmployeeDAO();
	  int employeeId;
	  String name;
	  double salary = 0;
	  int choice;
	  Employee employee;
	Scanner scanner = new Scanner(System.in);
	System.out.println("1. Add new Employee \n 2.Update Employee \n 3. Delete Employee \n 4.Get single Employee \n 5.Get all Employee");
	System.out.println("Enter choice");
	choice=scanner.nextInt();
	switch (choice) {
	case 1: 
		System.out.println("Enter employeeId");
		employeeId = scanner.nextInt();
		System.out.println("Enter name");
		name=scanner.next();
		System.out.println("Enter salary");
		salary=scanner.nextInt();
		employee = new Employee(employeeId , name , salary) ;
		if (employdao.addnewEmployee( employee)) {
			System.out.println(employee);
			
		}
	
	case 2: 
		System.out.println("Enter employeeId");
		employeeId = scanner.nextInt();
		System.out.println("Enter name");
		name=scanner.next();
		System.out.println("Enter salary");
		salary=scanner.nextInt();
		employee = new Employee(employeeId , name , salary) ;
		if (employdao.updateEmployee( employee)) {
			System.out.println(employee);
		}
	case 3:
		System.out.println("Enter employeeId");
		employeeId = scanner.nextInt();
		employdao.deleteEmployeeByEmployeeId( employeeId);
	
	case 4:
		System.out.println("Enter employeeId");
		employeeId = scanner.nextInt();
		employdao.getEmployeeByEmplpoyeeId( employeeId);
		
	case 5:
		employdao.getAllEmployee();
		
	}
}
}
		
	
			


