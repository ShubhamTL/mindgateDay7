package com.mindgate.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.mindgate.pojo.Employee;

public class EmployeeDAO {
 private Set<Employee> employeeSet = new HashSet<Employee>();
 
 // add new employee
 public boolean addnewEmployee(Employee employee) {
	 return employeeSet.add(employee);
 }

 // update existing employee
 public boolean updateEmployee(Employee employee) {
	 for (Employee emp : employeeSet) {
		if (emp.getEmployeeId() ==employee.getEmployeeId()) {
			emp.setName(employee.getName());
			emp.setSalary(employee.getSalary());
			return true;
		}
	}
	 return false;
 }
//  delete employee
 public boolean deleteEmployeeByEmployeeId(int employeeId) {
	 for (Employee emp1 : employeeSet) {
		if (emp1.getEmployeeId()== Employee.getEmployeeId()) {
			return employeeSet.remove(employee);
			
		}
	}
	 return false;
 }
 
 // get single employee by employee id
 public Employee getEmployeeByEmplpoyeeId(int employeeId) {
	 for (Employee emp2 : employeeSet) {
		if (emp2.getEmployeeId()== employee.getEmployeeId()) {
			return Employee;
		}
	}
	 return null;
 }
 // get all the employee
	 public Set< Employee> getAllEmployee(){
		 
		 return employeeSet;
	 }
 }

